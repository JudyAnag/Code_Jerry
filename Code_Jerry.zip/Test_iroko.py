import speech_recognition as sr
import pyttsx3
import pywhatkit
import datetime
import wikipedia
import pyjokes
from pyfirmata import Arduino, util
import time

listener = sr.Recognizer()
engine = pyttsx3.init()
voices = engine.getProperty('voices')
engine.setProperty('voice',voices[1].id)


def talk(text):
   engine.say(text)
   engine.runAndWait()

def take_command():
    try :
       with sr.Microphone() as source :
           print('listening...')
           voice = listener.listen(source)
           command = listener.recognize_google(voice)
           command = command.lower()
           if 'jerry' in command :
              command = command.replace('jerry','')
              print(command)
    except :
       pass
    return command

def ard():
    carte = Arduino('COM3')
    acquisition = util.Iterator(carte)
    acquisition.start()
    led13 = carte.get_pin('d:13:i')
    time.sleep(1.0)
    print("Début du test")
    led13.write(1)
    time.sleep(5)
    led13.write(0)
    carte.exit()

def run_alexa():
    command_order = take_command()
    if 'play' in command_order:
       song = command_order.replace('play','')
       talk('playing' + song)
       pywhatkit.playonyt(song)
    elif 'time' in command_order:
       time = datetime.datetime.now().strftime('%H:%M')
       talk('it is' + time)
    elif 'who is' in command_order:
        person = command_order.replace('who is', '') 
        info = wikipedia.summary(person, 1)
        print(info)
        talk(info)
    elif 'date' in command_order:
       talk('sorry, I have a headache')
    elif 'are you single' in command_order:
       talk('I am a relationship with wifi')
    elif 'joke' in command_order:
       talk(pyjokes.get_joke())
    elif 'hello' in command_order:
        ard()
        talk('the light is on. Look at')
    else : 
       talk('Please say the command again')

run_alexa()

